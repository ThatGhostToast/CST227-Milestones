﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ConsoleMinesweeper;


namespace Program
{
    /// <summary>
    /// Zac Almas
    /// CST-227
    /// 1/16/21
    /// This is my own code for milestone 1
    /// </summary>
    class Program
    {
        /// <summary>
        /// Main method that generates a minesweeper board
        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args)
        {
            //initialize some variables 
            int difficulty;
            bool valid = false;

            //Prompt the user
            Console.Out.WriteLine("Welcome to Minesweeper! Please select a difficulty: ");
            Console.Out.WriteLine("(1) Easy: 15% of the board is live bombs");
            Console.Out.WriteLine("(2) Medium: 30% of the board is live bombs");
            Console.Out.WriteLine("(3) Hard: 60% of the board is live bombs");
            Console.Out.WriteLine("(4) Quit");

            //Small do while statement that makes sure the user inputs a number
            do
            {
                string decision = Console.ReadLine();
                valid = int.TryParse(decision, out difficulty);
            } while (!valid);

            //Displays game board
            Board game = new Board(10, difficulty);
            game.setupLiveNeighbors();
            game.calculateLiveNeighbors();
            game.displayGame();

            //Stops the console from closing
            Console.Read();
           
        }

        static public void displayBoard()
        {
            
            for (int x = 0; x < 10; x++)
            {
                Console.WriteLine();
                for (int y = 0; y < 10; y++)
                {
                    
                }
            }

        }
    }
}
